const sampleDoctors = [
  {
    name: 'Dr. Aarti Joshi',
    location: 'Chennai',
    photo: 'vite.svg',
    specialization: 'Pediatrician',
  },
  {
    name: 'Dr. Aarti Joshi',
    location: 'Chennai',
    photo: 'vite.svg',
    specialization: 'Pediatrician',
  },
  {
    name: 'Dr. Aarti Joshi',
    location: 'Chennai',
    photo: 'vite.svg',
    specialization: 'Pediatrician',
  },
  {
    name: 'Dr. Aarti Joshi',
    location: 'Chennai',
    photo: 'vite.svg',
    specialization: 'Pediatrician',
  },
  {
    name: 'Dr. Aarti Joshi',
    location: 'Chennai',
    photo: 'vite.svg',
    specialization: 'Pediatrician',
  },
  {
    name: 'Dr. Ravi Patel',
    location: 'trichy',
    photo: 'vite.svg',
    specialization: 'Neurologist',
  },
  {
    name: 'Dr. Ravi Patel',
    location: 'trichy',
    photo: 'vite.svg',
    specialization: 'Neurologist',
  },
  {
    name: 'Dr. Ravi Patel',
    location: 'trichy',
    photo: 'vite.svg',
    specialization: 'Neurologist',
  },
  {
    name: 'Dr. Ravi Patel',
    location: 'trichy',
    photo: 'vite.svg',
    specialization: 'Neurologist',
  },
  {
    name: 'Dr. Ravi Patel',
    location: 'trichy',
    photo: 'vite.svg',
    specialization: 'Neurologist',
  },

]

export default sampleDoctors